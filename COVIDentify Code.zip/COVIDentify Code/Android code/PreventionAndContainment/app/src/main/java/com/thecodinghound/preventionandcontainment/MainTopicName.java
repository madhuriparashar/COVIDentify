package com.thecodinghound.preventionandcontainment;

import android.os.Parcel;
import android.os.Parcelable;

public class MainTopicName implements Parcelable {

    String Title,Content,Date;
    int userPhoto,id;




    public MainTopicName() {
    }


    public MainTopicName(String title, String content, String date, int userPhoto) {
        Title = title;
        Content = content;
        Date = date;
        this.userPhoto = userPhoto;
    }

    protected MainTopicName(Parcel in) {
        Title = in.readString();
        Content = in.readString();
        Date = in.readString();
        userPhoto = in.readInt();
        id = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Title);
        dest.writeString(Content);
        dest.writeString(Date);
        dest.writeInt(userPhoto);
        dest.writeInt(id);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<MainTopicName> CREATOR = new Creator<MainTopicName>() {
        @Override
        public MainTopicName createFromParcel(Parcel in) {
            return new MainTopicName(in);
        }

        @Override
        public MainTopicName[] newArray(int size) {
            return new MainTopicName[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public void setContent(String content) {
        Content = content;
    }

    public void setDate(String date) {
        Date = date;
    }

    public void setUserPhoto(int userPhoto) {
        this.userPhoto = userPhoto;
    }

    public String getTitle() {
        return Title;
    }

    public String getContent() {
        return Content;
    }

    public String getDate() {
        return Date;
    }

    public int getUserPhoto() {
        return userPhoto;
    }
}
