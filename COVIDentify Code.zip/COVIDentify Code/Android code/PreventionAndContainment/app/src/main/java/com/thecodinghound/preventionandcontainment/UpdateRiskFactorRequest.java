package com.thecodinghound.preventionandcontainment;

import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class UpdateRiskFactorRequest  extends StringRequest
{
    private static final String Login_Request_URL= "https://preventionandcontainmentfromcorona.000webhostapp.com/UpdateRiskfactor.php";
    private Map<String, String> params;

    public UpdateRiskFactorRequest( String phone, String riskfactor, Response.Listener<String> listener)
    {
        super(Request.Method.POST, Login_Request_URL,listener,null);
        params = new HashMap<>();
        params.put("phone",phone);
        params.put("riskfactor",riskfactor);
        Log.d("LoginRequest" + phone,riskfactor);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}


