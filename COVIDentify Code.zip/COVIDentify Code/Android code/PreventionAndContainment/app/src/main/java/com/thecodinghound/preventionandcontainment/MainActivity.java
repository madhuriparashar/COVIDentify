package com.thecodinghound.preventionandcontainment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import com.darwindeveloper.horizontalscrollmenulibrary.custom_views.HorizontalScrollMenuView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static com.thecodinghound.preventionandcontainment.LoginActivity.KEY_LOGIN;
import static com.thecodinghound.preventionandcontainment.LoginActivity.SHARED_PREFS;

public class MainActivity extends AppCompatActivity
implements NavigationView.OnNavigationItemSelectedListener{

    private static final String TAG = "MainActivity" ;
    private Button button;
    public static NavigationView navigationView;
    public static Fragment fragmentCurrent;
    private int currentMenuItem;
    private DrawerLayout drawer;

    HorizontalScrollMenuView menu;

    public String riskfactor;
    public String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        currentMenuItem = R.id.nav_dashboard;

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        Log.i("Main Activity", "" + currentMenuItem);

        if (savedInstanceState == null) {
            fragmentCurrent = new PrevntionTips();
            getSupportFragmentManager().beginTransaction().add(R.id.fragment_container,
                    new PrevntionTips()).commit();
            navigationView.setCheckedItem(R.id.nav_dashboard);

        }

        menu = (HorizontalScrollMenuView) findViewById(R.id.menu);
        initMenu();


        Intent intent = getIntent();
        phone = intent.getStringExtra("phone");
        riskfactor = intent.getStringExtra("riskfactor");
    }

    private void initMenu(){
        menu.addItem("Precautions",R.drawable.prevention);
        menu.addItem("Self Assessment Test",R.drawable.testicon);
        menu.addItem("Create a group",R.drawable.group);
        menu.addItem("Yoga Tips",R.drawable.meditation);
        menu.addItem("List of Volunteers",R.drawable.volunteer);
        menu.addItem("FAQ",R.drawable.question);
        menu.addItem("Feedback",R.drawable.feedback);
        menu.addItem("About Us",R.drawable.aboutus);



        menu.setOnHSMenuClickListener(new HorizontalScrollMenuView.OnHSMenuClickListener() {
            @Override
            public void onHSMClick(com.darwindeveloper.horizontalscrollmenulibrary.extras.MenuItem menuItem, int position) {
                if(position == 0){

                    fragmentCurrent = new PrevntionTips();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new PrevntionTips()).addToBackStack(null).commit();
                    navigationView.setCheckedItem(R.id.nav_dashboard);
                }
                else if(position == 1){
                    fragmentCurrent = new FragmentTest();
                    Bundle b2 = new Bundle();
                    b2.putString("phone1",phone);
                    b2.putString("riskfactor1",riskfactor);
                    fragmentCurrent.setArguments(b2);
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            fragmentCurrent).addToBackStack(null).commit();

                    navigationView.setCheckedItem(R.id.nav_dashboard);
                }
                else if(position == 2){
                    fragmentCurrent = new FragmentGroup();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new FragmentGroup()).addToBackStack(null).commit();
                    navigationView.setCheckedItem(R.id.nav_dashboard);
//                    Intent launchIntent = getPackageManager().getLaunchIntentForPackage("org.telegram.messenger");
//
//                    if(launchIntent != null){
//                        startActivity(launchIntent);
//                        Toast.makeText(MainActivity.this, "Soon this feature will be added. Till then....Use Telegram", Toast.LENGTH_SHORT).show();
//
//                    }
//                    else{
//                        Toast.makeText(MainActivity.this, "Please download Telegram.", Toast.LENGTH_SHORT).show();
//                    }
                }
                else if(position == 3){
                    fragmentCurrent = new FragmentYoga();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new FragmentYoga()).addToBackStack(null).commit();
                    navigationView.setCheckedItem(R.id.nav_dashboard);
                }
                else if(position == 4){
                    fragmentCurrent = new FragmentVolunteer();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new FragmentVolunteer()).addToBackStack(null).commit();
                    navigationView.setCheckedItem(R.id.nav_dashboard);

//                  Intent intent = new Intent(Intent.ACTION_VIEW);
//                  intent.setData(Uri.parse("https://www.mygov.in/task/join-war-against-covid-19-register-volunteer"));
//                  startActivity(intent);
                }
                else if(position == 5){
                    fragmentCurrent = new FragmentFaq();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new FragmentFaq()).addToBackStack(null).commit();
                    navigationView.setCheckedItem(R.id.nav_dashboard);
                }
                else if(position == 6){
                    fragmentCurrent = new FragmentEmail();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new FragmentEmail()).addToBackStack(null).commit();
                    navigationView.setCheckedItem(R.id.nav_feedback);
                }

                else if(position == 7)
                {
                    fragmentCurrent = new FragmentAboutUs();
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                            new FragmentAboutUs()).addToBackStack(null).commit();
                    navigationView.setCheckedItem(R.id.nav_aboutus);
                }


            }
        });

    }
        public void onBackPressed() {
            Log.d(TAG, "onBackPressed: +"+ fragmentCurrent);
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            if (drawer.isDrawerOpen(GravityCompat.START)) {
                drawer.closeDrawer(GravityCompat.START);
            } else {
                if (fragmentCurrent instanceof PrevntionTips) {
                    getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    Log.d(TAG, "onBackPressed: 1");
                    super.onBackPressed();
                    finishAffinity();
                } else {
                    getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    replaceFragment(new PrevntionTips());
                    Log.d(TAG, "onBackPressed: "+ 2);
                }
            }
        }

        public boolean onNavigationItemSelected (MenuItem item){
            // Handle navigation view item clicks here.
            int id = item.getItemId();
            if(id == currentMenuItem){
                drawer.closeDrawer(GravityCompat.START);
                return false;
            }

            if (id == R.id.nav_dashboard) {
                fragmentCurrent = new PrevntionTips();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new PrevntionTips()).addToBackStack(null).commit();

            }
            else if (id == R.id.nav_feedback) {
                fragmentCurrent = new FragmentEmail();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentEmail()).addToBackStack(null).commit();
            } else if (id == R.id.nav_aboutus) {
                fragmentCurrent = new FragmentAboutUs();
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                        new FragmentAboutUs()).addToBackStack(null).commit();
            }
            else if (id == R.id.nav_Privacy) {
                Intent intent = new Intent(MainActivity.this, PrivacyPolicy.class);
                startActivity(intent);
            }
            else if (id == R.id.nav_termsandconditions) {
                Intent intent = new Intent(MainActivity.this, TermsAndConditions.class);
                startActivity(intent);
            }
            else if (id == R.id.nav_share) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_TEXT, "Url of this app will be added");
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "share via"));
            }
            else if(id == R.id.nav_Logout){
//                SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
//                SharedPreferences.Editor editor = sharedPreferences.edit();
//                editor.putInt(KEY_LOGIN, 0);
//                editor.commit();
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.putExtra("logout",1);
                startActivity(intent);
                finish();
            }
            currentMenuItem = id;
            drawer.closeDrawer(GravityCompat.START);
            return true;
        }


        private void replaceFragment(Fragment fragment){
            fragmentCurrent = fragment;
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment)
                    .addToBackStack(null).commit();
            navigationView.setCheckedItem(R.id.nav_dashboard);
        }



}
