package com.thecodinghound.preventionandcontainment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;

public class PrevntionTips extends Fragment implements MainAdapter.OnNoteListener1{

//    private WebView myWebView;

    View v;
    private RecyclerView myrecyclerview;
    MainAdapter recyclerViewAdapter;

    private List<MainTopicName> firstcontact;

   JavaDBHelper practiceDbHelper;

    private static final String TAG = "FragmentAnalytical";
    boolean isDark = false;

    EditText search_input;
    CharSequence search = "";
    String currentDate;
    FloatingActionButton fabSwitcher;
    ConstraintLayout rootLayout;
    private static final int Quantitative_CODE_QUIZ = 1;
    int pos;

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_prevention_tips, container, false);

        search_input = v.findViewById(R.id.analytical_search_input);
        rootLayout = v.findViewById(R.id.analytical_root_layout);

        loadData();



        search_input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                recyclerViewAdapter.getFilter().filter(charSequence);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        return v;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        practiceDbHelper = JavaDBHelper.getInstance(getActivity());
        firstcontact = practiceDbHelper.getAllTopics();
        if (firstcontact == null) {
            Log.d(TAG, " NoTopics");
        }
    }


    @Override
    public void onNoteClick(View v,int position, String str) {
        this.pos = position;
        Log.d(TAG, "onNoteClick ");
        String str1 = str;
        Intent intent = new Intent(getActivity(), PreventionContentDisplay.class);
        intent.putExtra("Example_Item", firstcontact.get(position));
        intent.putExtra("pos", position);
        intent.putExtra("Title",str1);
        startActivityForResult(intent, Quantitative_CODE_QUIZ);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Quantitative_CODE_QUIZ) {
            if (resultCode == RESULT_OK) {
                getdate();
                MainTopicName at = firstcontact.get(pos);
                at.setDate(currentDate);
                boolean isupdate = (boolean) practiceDbHelper.updateDate(at);
                if(isupdate)
                {
                    firstcontact.set(pos,at);
                    recyclerViewAdapter.notifyDataSetChanged();
                    MainTopicName pt = firstcontact.get(pos);
                    Log.d(TAG, String.valueOf(at));
                }
                else
                {
                    Toast.makeText(getActivity(), "Error Occured", Toast.LENGTH_SHORT).show();
                }

            }
        }

    }


    private void loadData()
    {
        myrecyclerview =  v.findViewById(R.id.analyticalrecyclerview);
        recyclerViewAdapter = new MainAdapter(getContext(),firstcontact, this);
        myrecyclerview.setLayoutManager(new LinearLayoutManager(getActivity()));
        myrecyclerview.setAdapter(recyclerViewAdapter);

    }

    private void getdate()
    {
        Calendar calendar = Calendar.getInstance();
        currentDate = DateFormat.getInstance().format(calendar.getTime());
        Log.d(TAG, "getdate: "+currentDate);
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void saveThemeStatePref(boolean isDark) {

        SharedPreferences pref = getActivity().getApplicationContext().getSharedPreferences("myAnaPref", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("isAnalyticDark", isDark);
        editor.commit();
    }

    private boolean getThemeStatePref() {

        SharedPreferences pref = getActivity().getApplicationContext().getSharedPreferences("myAnaPref", MODE_PRIVATE);
        boolean isDark = pref.getBoolean("isAnalyticDark", false);
        return isDark;

    }



}


// myWebView = (WebView) v.findViewById(R.id.webview);
//         myWebView.setWebViewClient(new WebViewClient());
//         myWebView.loadUrl("https://preventionandcontainment.000webhostapp.com/");
//         WebSettings webSettings = myWebView.getSettings();
//         webSettings.setJavaScriptEnabled(true);
