package com.thecodinghound.preventionandcontainment;

import android.provider.BaseColumns;

public class JavaContract {

    private JavaContract(){

    }



    public static class JavaTopics implements BaseColumns {
        public static final String TABLE_NAME = "javatable";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_CONTENT = "content";
        public static final String COLUMN_DATE = "date";
        public static final String COLUMN_USERPHOTO = "userphoto";
    }
}
