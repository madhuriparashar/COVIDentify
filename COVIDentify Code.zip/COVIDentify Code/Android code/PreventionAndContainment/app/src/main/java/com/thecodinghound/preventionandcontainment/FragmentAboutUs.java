package com.thecodinghound.preventionandcontainment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


public class FragmentAboutUs extends Fragment {
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v =  inflater.inflate(R.layout.aboutus, container, false);

        final ImageView companylogo = v.findViewById(R.id.aboutusiconicon);
        companylogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Animation zoomAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.extraanim);
                companylogo.startAnimation(zoomAnimation);
            }
        });
        return v;
    }
}
