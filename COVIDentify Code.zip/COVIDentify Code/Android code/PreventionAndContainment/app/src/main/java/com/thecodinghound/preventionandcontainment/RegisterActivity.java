package com.thecodinghound.preventionandcontainment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText etname = (EditText) findViewById(R.id.etNamee);
        final EditText etusername = (EditText) findViewById(R.id.etUsername);
        final EditText etphonenumber = (EditText) findViewById((R.id.etPhoneNumber));
        final EditText etpassword = (EditText) findViewById((R.id.etPassword));
        final TextView backToLogin = (TextView) findViewById(R.id.lnkLogin);
//        final EditText etAddress = (EditText) findViewById(R.id.etAddress);

        backToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });


        final Button register = (Button) findViewById(R.id.button);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String name = etname.getText().toString();
                final String username = etusername.getText().toString();
                final String riskfactor = "pending";
                final String currentstatus = "pending";
                final String phone = etphonenumber.getText().toString();
                final String address = "NA";
                final String password = etpassword.getText().toString();

                if(name.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Name is mandatory",Toast.LENGTH_SHORT).show();
                }
                else if(username.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Username is mandatory",Toast.LENGTH_SHORT).show();
                }

                else if(!isValidPhone(phone)){
                    Toast.makeText(getApplicationContext(),"Phone number is not valid",Toast.LENGTH_SHORT).show();

                }
                else if(address.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Address is mandatory",Toast.LENGTH_SHORT).show();
                }
                else if(password.length() < 8){
                    Toast.makeText(getApplicationContext(),"Password should be minimum of 8 charcters",Toast.LENGTH_SHORT).show();
                }
                else{
                    Response.Listener<String> responseListener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONObject JSONresponse = new JSONObject(response);
                                boolean success = JSONresponse.getBoolean("success");

                                if (success) {

                                    AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                                    builder.setMessage("Phone Number already registered.").setNegativeButton("Retry", null)
                                            .create().show();


                                } else {
                                    Response.Listener<String> responseListener1 = new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {

                                            Log.d("response is", response);

                                            try {
                                                JSONObject jsonResponse = new JSONObject(response);
                                                boolean success = jsonResponse.getBoolean("success");

                                                Log.d("success", String.valueOf(success));
                                                if (success) {
                                                    Toast.makeText(getApplicationContext(),"Successfully Registered",Toast.LENGTH_LONG).show();
                                                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                                                    RegisterActivity.this.startActivity(intent);
                                                } else {
                                                    AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                                                    builder.setMessage("Registration Failed").setNegativeButton("Retry", null)
                                                            .create().show();
                                                }

                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    };

                                    RegisterRequest registerRequest = new RegisterRequest(name, username, phone, riskfactor, currentstatus,address, password, responseListener1);
                                    RequestQueue queue = Volley.newRequestQueue(RegisterActivity.this);
                                    queue.add(registerRequest);

                                }

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    UniqueUsernameRequest uniqueUsernameRequest = new UniqueUsernameRequest(phone, responseListener);
                    RequestQueue queue = Volley.newRequestQueue(RegisterActivity.this);
                    queue.add(uniqueUsernameRequest);
                }

            }
        });
    }


    private boolean isValidPhone(String phone)
    {
        boolean check=false;
        if(!Pattern.matches("[a-zA-Z]+", phone))
        {
            if(phone.length() < 6 || phone.length() > 13)
            {
                check = false;

            }
            else
            {
                check = true;

            }
        }
        else
        {
            check=false;
        }
        return check;
    }
}

