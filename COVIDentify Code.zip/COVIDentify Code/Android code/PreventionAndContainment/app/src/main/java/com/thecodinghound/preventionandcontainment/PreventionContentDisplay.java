package com.thecodinghound.preventionandcontainment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class PreventionContentDisplay extends AppCompatActivity {

    TextView txtView;
    private int position;
    private long backPressedTime;
    String title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_prevention_content_display);

        getSupportActionBar().hide();

        txtView = findViewById(R.id.stepsforprevention);
        Intent intent = getIntent();
        title = intent.getStringExtra("Title");
        position = intent.getIntExtra("pos", -1);
        Toast.makeText(this, " "+title, Toast.LENGTH_SHORT).show();

        loadData();

    }

    private void loadData() {
        if(title.equals("Minimal Common Measures")){
            txtView.setText("The best way to protect yourself from the COVID-19 virus is to avoid exposure. If you go out, wear a cloth face covering. Keep a distance of about 6 feet (2 meters) from others if the COVID-19 virus is spreading in your community, especially if you have a higher risk of serious illness. Avoid close contact with anyone who is sick or has symptoms. Also, avoid large events and mass gatherings.\n" +
                    "\n" +
                    "In addition, practice good hygiene. Wash your hands often with soap and water for at least 20 seconds, or use an alcohol-based hand sanitizer that contains at least 60% alcohol. Cover your mouth and nose with your elbow or a tissue when you cough or sneeze and then wash your hands or use hand sanitizer. Also, avoid touching your eyes, nose and mouth.\n" +
                    "\n" +
                    "If you feel sick, stay home. Don't visit public areas unless you're going to get medical care. Avoid taking public transportation if you're sick.\n" +
                    "\n" +
                    "And if you're at higher risk of serious illness, don't head out into the community just yet. It's safer to stay home. If other members of your household return to work or visit places where social distancing isn't possible, it's recommended that they isolate themselves from you.\n");
        }
        else if(title.equals("Getting restaurant takeout")){
            txtView.setText("Before you eat at a restaurant, check the restaurant's safety practices. Are the employees wearing cloth face coverings, regularly disinfecting high-touch surfaces and practicing social distancing? Is there good ventilation? Are tables set far enough apart from each other to allow for social distancing? Is the menu digital or disposable?\n\n" +
                    "Ideally, the restaurant won't offer salad bars, buffets and drink-filling stations that require people to use common utensils or dispensers. If you need to wait in line for service, maintain a distance of at least 6 feet (2 meters) from others. If possible, use touchless payment.\n" +
                    "\n" + "When ordering takeout, try to pay online or over the phone to limit contact with others. If you're having food delivered, ask for it to be left outside your home in a safe spot, such as the porch or your building's lobby. Otherwise, stay at least 6 feet (2 meters) away from the delivery person. If you're picking up your food at the restaurant, maintain social distancing while waiting in the pickup zone. After bringing home your food, wash your hands or use hand sanitizer.");
        }
        else if(title.equals("Pumping Gasoline"))
        {
            txtView.setText("Before pumping gas wipe down any handles or buttons you'll need to touch. After you finish fueling, apply hand sanitizer. Wash your hands when you get home or the next time you are near a sink.");
        }
        else if(title.equals("Non Contact Sports")){
            txtView.setText("Full array of training activities may be performed as individual or pair training - distancing norms of 1.5 to 2 metres between athletes and staff and exiting facility as soon as training is concluded. Personal equipment such as bow, gun, sword, javelin, discuss, rackets, etc, shall be used without sharing. Shared training equipment such as arrows, shuttlecocks, balls, targets, Olympic bar/ weights etc. must be disinfected after every single use and shall not be used to rub/touch face, remove sweat, cover mouth while hyperventilating etc. In the dire need of sharing any of such personally used equipment; equipment shall be properly disinfected after every single use as per the standard procedure using disinfectant, wearing face masks, gloves and personal precautionary equipment etc. Sports specify safety equipment such as helmet, eye protectors, face protectors shall not be shared.");
        }
        else if(title.equals("Grocery Shopping")){
            txtView.setText("Before going to get your groceries, consider visiting the chain's website to check on the precautions being taken. For smaller businesses, call the store.\n" +
                    "\n" +
                    "To make social distancing easy, visit the grocery store early in the morning or late at night, when the store might be less crowded. If you're at higher risk of serious illness, find out if the store has special hours for people in your situation and shop during these times. You might also consider ordering your groceries online for home delivery or curbside pickup.\n" +
                    "\n" +
                    "At the store, disinfect the handle of the shopping cart or basket. Stay at least 6 feet (2 meters) away from others while shopping and in lines. If possible, pay without touching money or a keypad or use hand sanitizer after paying. Also, apply hand sanitizer after you leave the store. When you get home, wash your hands.");
        }
        else if(title.equals("Going for a walk, run or bike ride with others")){
            txtView.setText("1. Maintain a distance of 12 feet from others: Dr. Vivek Gupta of Dayanand Medical College, Ludhiana said that in general, six feet physical distancing is required. But people breathe loudly while running. In such a situation, there is a danger of the mouth droplets going further away. So keep at least 12 to 20 feet of physical distance while jogging or walking.\n" +
                    "\n" +
                    "2. Always look in front: Do not think of any other thing while running. You will not be able to be cautious with this. Always look at the front. With this you will know if anything is coming in front of you, which will eventually prevent you from getting close to anyone. Run in a place where no one else is running. If the place is narrow and someone is coming from the front, change the track.\n" +
                    "\n" +
                    "3. Do not wear a mask that causes difficulty in breathing: According to America's Centre for Disease Control and Prevention, more oxygen is needed while running. Therefore, wearing a tight mask will cause breathlessness. It is better to wear a mask or face cover of good quality. Dr Vivek Gupta said that the mask should be lose enough so that it should hinder your breathing process.\n" +
                    "\n" +
                    "4. Wear masks as soon as people come near you: You can remove your mask while running alone, but stay alert and put the mask on as soon as you notice someone approaching towards you or coming near your track.\n" +
                    "\n" +
                    "5. Avoid going immediately to places where someone else is there: If someone else is running in the park where you have to run then stop for a while and wait keeping a safe distance. Otherwise, you can come in contact with his droplet in the air. According to Dr. Vivek Gupta, do not run in crowded places and streets.\n" +
                    "\n" +
                    "6. Do not touch anything: Avoid touching anything when you step outside. Do not even touch the gate while entering the park etc. Gates are already being kept open in many places.\n" +
                    "\n" +
                    "7. When and where to run: You should know the rules of your area. A number of restrictions have been imposed by the local administration at all places. So you should know when you can leave the house and where you can or cannot go.\n" +
                    "\n" +
                    "8. Run slowly and comfortably: Do not run too often. Run slow on the first day. Your ability will increase day by day. On the other hand, if you used to run before the onset of the pandemic, then also put less emphasis on running. That is to run with less intensity. Pay attention to the minute and do not see how many miles you have ran.\n" +
                    "\n" +
                    "9. Talk clearly: If someone started talking to you while running, talk to him from a distance. Stand away and talk clearly in such a way that he understands your point and does not have to come close.");
        }
        else if(title.equals("Staying at a hotel for 2 nights"))
        {
                txtView.setText("1. All guests entering the hotel follow stringent thermal checks. Hand sanitization at reception and lobby. Luggage is sanitized on arrival.\n" +
                        "2. Guest recent travel history is enquired and recorded.\n" +
                        "3. Heath fitness medical certificate to be obtained from guests at the time of arrival at the hotel.\n" +
                        "4. It is mandatory for all the guests to download Aarogya Setu app in their mobile phones/ tabs at the time of arrival at the hotel.\n" +
                        "5. All vehicles go through a sanitization & fumigation process after every pick-up and drop. We do not allow more than two passengers as per the prescribed rules framed by the government.\n" +
                        "6. Sanitizer stations on all lift landings and all guest corridors and limiting the number of guests within the elevators to maximum 2 or 3 depending upon the size.\n" +
                        "7. Hand sanitizers and face masks are now an integral part of the guest amenities and are being placed in all vehicles, rooms and public areas.\n" +
                        "8. Introduction of touchless digital check-in and check-out facilities to minimize physical contact.\n" +
                        "9. Prior to check-in, information of doctors, medical shops and other such information to be made handy to the guest through WhatsApp/ SMS. Set protocols to be followed in case any guest/ staff develops COVID-19 symptoms while in hotel/premises.\n" +
                        "10. All rooms being pre-sanitized as per the laid down SOP by undertaking sanitization process with proper PPE gear with gloves, masks etc.\n" +
                        "11. Restaurants are having special seating arrangement to maintain the 3 feet distance amongst each guest. QR code-based menu ordering and payments to be the new norm. Buffet to be removed and in-case it is required, then only the specially trained hotel team members are allowed to serve the guests.\n" +
                        "12. Use of disposable and bio-degradable cutlery and crockery wherever possible. If not possible, the same will be placed in sanitized pouches.\n" +
                        "13. Swimming pool, Spa, Gym will be kept shut as per the lock down protocols.");
        }
        else if(title.equals("Visiting Doctor"))
        {
            txtView.setText("1. Do your homework\n" +
                    "Before you make an appointment, call the clinic or check its website to find out what's being done to keep people safe during the COVID-19 pandemic. Check for information about:\n" +
                    "\n" +
                    "a) Requirements regarding mask wearing by staff and visitors\n" +
                    "b) Cleaning protocols and sanitizing measures for exam rooms, waiting areas, restrooms, elevators and other frequently touched surfaces\n" +
                    "c) Social distancing practices at check-in, in waiting areas and in exam rooms\n" +
                    "d) Limits on the number of people who can be in the clinic at the same time\n" +
                    "e) Screening questions and temperature checks for staff and visitors at all entrances\n" +
                    "f) Special measures, spatial isolation or instructions for people who have or may have COVID-19\n" +
                    "g) How doctors and other staff are using personal protective equipment (PPE)\n" +
                    "h) Video (telemedicine) appointment options\n" +
                    "\n" +
                    "2. Before you head to the clinic\n" +
                    "Shortly before the day of your appointment, you may get a call from someone at the clinic asking if you have symptoms of COVID-19, such as fever, cough and shortness of breath. If you have symptoms, you may be given specific instructions.\n" +
                    "Clinic staff may tell you to bring and wear a mask. Some clinics may also ask that you bring only one person with you to your appointment.\n" +
                    "Ask questions you may have about safety procedures. For example, you may want to ask if the clinic can send your bill electronically or by mail. These may be good options so you don't have to worry about picking up germs when you check out at the clinic.\n" +
                    "\n" +
                    "3. Wear a mask\n" +
                    "A health care provider and a person wearing masks.\n" +
                    "Remember to follow these standard precautions when you're at the clinic, such as:\n" +
                    "Wear a cloth face mask. Most clinics require that people wear masks during the COVID-19 pandemic. If you don't have one, your clinic may be able to provide you with one.\n" +
                    "Wash your hands with soap and water for at least 20 seconds or use hand sanitizer with 60% alcohol before or after touching any surfaces in public areas, such as in the waiting area.\n" +
                    "Avoid touching your face, including your eyes, nose and mouth.\n" +
                    "Cover your cough or sneeze with a tissue or your elbow, and throw away the tissue. When wearing a mask, cough or sneeze into the mask.\n" +
                    "\n" +
                    "4. Use hand sanitizer\n" +
                    "\n" +
                    "5. Practice social distancing\n" +
                    "Many clinics have social distance markers on the floor to note how far apart to stand.\n" +
                    "Aim to keep social distance, or about 6 feet (2 meters) away from others while at the clinic, including when you're in line and in the waiting area. Some clinics have signs or markings on the floor to help visitors maintain physical distancing (social distancing). If an area looks crowded, move to another part of the clinic.\n" +
                    "\n" +
                    "6. Waiting areas\n" +
                    "A person cleans a surface in a waiting area.\n" +
                    "Try to avoid contact with frequently touched surfaces, such as doorknobs, elevator buttons and touchpads. While they're cleaned regularly, there's still the chance they have germs on them. Wear gloves or use a tissue to open doors and press elevator buttons. If you need to use a touchpad or touch a commonly used surface, wash your hands or use a hand sanitizer afterward.\n" +
                    "\n" +
                    "7. Use touchless payment options\n" +
                    "When it's time to check out, opt for touchless payment if possible, such as a mobile payment system. If that's not an option, use credit cards, cash or checks, and then use hand sanitizer containing at least 60% alcohol. When you get home, wash your hands well with soap and water.\n" +
                    "\n" +
                    "8. Try telemedicine for appointments\n" +
                    "Ask your doctor about telemedicine appointment options, such as a video consult. It can be an effective way for you to follow-up with your doctor from home. Or you may be able to have a telemedicine appointment instead of an in-person visit. You also may be able to have a phone consult with your doctor. Ask your doctor if you can send secure messages or emails with questions.\n" +
                    "\n" +
                    "9. Plan ahead for prescriptions\n" +
                    "If you have a new prescription or need to refill existing ones, consider mail order. Check with your doctor about getting larger supplies of your prescriptions that last longer and require fewer pharmacy visits. If you need to get a prescription locally, call ahead or order online. Ask if delivery is an option or whether the pharmacy has drive-through or curbside pickup options.\n" +
                    "Although it's natural to have concerns about receiving care during the COVID-19 pandemic, it's possible to visit your doctor and be safe.");
        }
        else if(title.equals("Going to Banks")){
            txtView.setText("During visits to the bank, use the ATM, if possible. Clean the ATM keyboard with a disinfecting wipe before using it. When you are done, apply hand sanitizer. Wash your hands when you get home.");
        }
        else if(title.equals("Eating in a restaurant(outside)")){
            txtView.setText("Before you eat at a restaurant, check the restaurant's safety practices. Are the employees wearing cloth face coverings, regularly disinfecting high-touch surfaces and practicing social distancing? Is there good ventilation? Are tables set far enough apart from each other to allow for social distancing? Is the menu digital or disposable?\n" +
                    "Ideally, the restaurant won't offer salad bars, buffets and drink-filling stations that require people to use common utensils or dispensers. If you need to wait in line for service, maintain a distance of at least 6 feet (2 meters) from others. If possible, use touchless payment.\n" +
                    "\n" +
                    "When ordering takeout, try to pay online or over the phone to limit contact with others. If you're having food delivered, ask for it to be left outside your home in a safe spot, such as the porch or your building's lobby. Otherwise, stay at least 6 feet (2 meters) away from the delivery person. If you're picking up your food at the restaurant, maintain social distancing while waiting in the pickup zone. After bringing home your food, wash your hands or use hand sanitizer.\n");
        }
        else if(title.equals("Having dinner at someone else's house")){
            txtView.setText("1. As much as possible, keep away from other people and pets in your home.\n" +
                    "2. Wear a cloth face covering (or face mask, if you have one) if they must be around other people. Cloth face coverings are for use only by people older than 2 years old who are not having trouble breathing. Do not leave a child alone while they're wearing a cloth face covering. To see how to put on and remove cloth face coverings and face masks, clean them, or make your own cloth face covering, check the CDC's guide.\n" +
                    "3. Cover coughs and sneezes with a tissue, throw the tissue away, and then wash their hands right away. Wash with soap and water for at least 20 seconds, or use alcohol-based hand sanitizer.\n" +
                    "4. If possible, stay in a bedroom and use a bathroom separate from other people in the home.\n" +
                    "5. Use separate dishes, glasses, cups, and eating utensils and not share these with other household members. After use, run them through the dishwasher or wash with very hot soapy water.\n" +
                    "6. Use separate bedding and towels and not share these with other household members. ");
        }
        else if(title.equals("Going to a beach")){
            txtView.setText("1. Keep social distancing.\n" +
                    "Treat everyone like they were wearing thongs and had major flatulence problems. That is, keep your distance, at least six feet away if not further from everyone else. After all, despite the wind, sun, and waves, don’t forget that the Covid-19 coronavirus may still be around.\n" +
                    "\n" +
                    "2. Take reasonable precautions with the water.\n" +
                    "You may be at relatively low risk of catching the virus through the water, as I covered previously for Forbes. Even though the virus may be able to survive in the water, the motion of the ocean can dilute the concentration of the virus fairly quickly. Nonetheless, take appropriate precautions. Continue to keep your distance from others when you are in the water, especially when one of those others is actively having diarrhea in the water. Typically, active diarrhea is not a come hither sign. And for Pete’s sake, and everyone else’s, don’t drink ocean water.\n" +
                    "\n" +
                    "3. Be careful with public areas and objects.\n" +
                    "Plan ahead. Try to minimize what you need to touch. For example, consider emptying things out before you go to the beach so that you don’t have to use the public restroom. In this case, “things” doesn’t mean your fanny pack but instead means your bladder and your colon.\n" +
                    "\n" +
                    "4. Avoid touching your face and wash your hands frequently.\n" +
                    "That song by The Weeknd “Can't Feel My Face” applies here as well. Don’t touch that Jupiter-sized thing that sits atop your neck with unwashed hands. Wash your hands frequently and thoroughly.\n" +
                    "\n" +
                    "5. Don’t drown.\n" +
                    "“Except for drowning, it was a good trip to the beach,” is not something that people will typically say. Social distancing doesn’t mean stay as far away from the lifeguard as possible. Be extra cautious as the beach may be understaffed so that you may not be rescued as readily should you get into trouble.\n" +
                    "\n" +
                    "6. Protect your skin from the sun.\n" +
                    "Staying inside all this time may have left your skin a bit like uncooked dough and thus even more sensitive to sun exposure. Cover up your exposed parts with sunscreen but do it yourself. This is not the time to ask a stranger to put some lotion on you.\n" +
                    "\n" +
                    "7. Follow the bleeping rules.\n" +
                    "Check the beach’s rules in advance. Be aware of the opening and closing times. Getting arrested for being on the beach when you are not supposed to be there will ruin a beach trip. Some beaches will not allow out-of-state visitors. So check what state you are in and compare it to what it says on your driver’s license. If wearing a mask is required, cover your face. Do it for other people. Refusing to cover your face does not prove your independence or your masculinity. It just proves that you are not Batman.\n" +
                    "Again, just because beaches are re-opening doesn’t mean that it is time to lose all control. You are going to the beach, not invading Normandy.");
        }
        else if(title.equals("Shopping at a mall"))
        {
            txtView.setText("Shopping malls shall ensure the following arrangements:\n" +
                    "i. Entrance to have mandatory hand hygiene (sanitizer dispenser) and thermal\n" +
                    "screening provisions.\n" +
                    "ii. Only asymptomatic customers/visitors shall be allowed.\n" +
                    "iii. All workers/customers/visitors to be allowed entry only if using face cover/masks.\n" +
                    "The face cover/masks has to be worn at all times inside the shopping mall.\n" +
                    "iv. Posters/standees/AV media on preventive measures about COVID-19 to be\n" +
                    "displayed prominently.\n" +
                    "v. Staggering of visitors to be done, if possible.\n" +
                    "vi. Adequate manpower shall be deployed by Mall Management for ensuring social\n" +
                    "distancing norms.\n" +
                    "vii. All employees who are at higher risk i.e. older employees, pregnant employees and\n" +
                    "employees who have underlying medical conditions, to take extra precautions. They\n" +
                    "should preferably not be exposed to any front-line work requiring direct contact\n" +
                    "with the public. Shopping Mall management to facilitate work from home wherever\n" +
                    "feasible.\n" +
                    "viii. Proper crowd management in the parking lots and outside the premises – duly\n" +
                    "following social distancing norms shall be ensured.\n" +
                    "ix. Valet parking, if available, shall be operational with operating staff wearing face\n" +
                    "covers/ masks and gloves as appropriate. A proper disinfection of steering, door\n" +
                    "handles, keys, etc. of the vehicles should be taken up.\n" +
                    "x. Any shops, stalls, cafeteria etc., outside and within the premises shall follow social\n" +
                    "distancing norms at all times.\n" +
                    "xi. Specific markings may be made with sufficient distance to manage the queue and\n" +
                    "ensure social distancing in the premises.\n" +
                    "xii. Preferably separate entry and exits for visitors, workers and goods/supplies shall be\n" +
                    "organized.\n" +
                    "xiii. The staff for home deliveries shall be screened thermally by the shopping mall\n" +
                    "authorities prior to allowing home deliveries.\n" +
                    "xiv. Required precautions while handling supplies, inventories and goods in the shopping\n" +
                    "mall shall be ensured. Proper queue management and disinfection shall be\n" +
                    "organized.\n" +
                    "xv. Maintaining physical distancing of a minimum of 6 feet, when queuing up for entry\n" +
                    "and inside the shopping mall as far as feasible.\n" +
                    "xvi. Number of customers inside the shop to be kept at a minimum, so as to maintain\n" +
                    "the physical distancing norms.\n" +
                    "xvii. Seating arrangement, if any, to be made in such a way that adequate social\n" +
                    "distancing is maintained.\n" +
                    "xviii. Number of people in the elevators shall be restricted, duly maintaining social\n" +
                    "distancing norms.\n" +
                    "xix. Use of escalators with one person on alternate steps may be encouraged.\n" +
                    "xx. For air-conditioning/ventilation, the guidelines of CPWD shall be followed which\n" +
                    "inter alia emphasises that the temperature setting of all air conditioning devices\n" +
                    "should be in the range of 24-30oC, relative humidity should be in the range of 40-\n" +
                    "Page 3 of 3\n" +
                    "70%, intake of fresh air should be as much as possible and cross ventilation should\n" +
                    "be adequate.\n" +
                    "xxi. Large gatherings/congregations continue to remain prohibited.\n" +
                    "xxii. Effective and frequent sanitation within the premises shall be maintained with\n" +
                    "particular focus on lavatories, drinking and hand washing stations/areas.\n" +
                    "xxiii. Cleaning and regular disinfection (using 1% sodium hypochlorite) of frequently\n" +
                    "touched surfaces (door knobs, elevator buttons, hand rails, benches, washroom\n" +
                    "fixtures, etc.) to be made mandatory in all malls in common areas as well as inside\n" +
                    "shops, elevators, escalators etc.\n" +
                    "xxiv. Proper disposal of face covers / masks / gloves left over by visitors and/or\n" +
                    "employees should be ensured.\n" +
                    "xxv. Deep cleaning of all washrooms shall be ensured at regular intervals.\n" +
                    "xxvi. In the food-courts:\n" +
                    "a. Adequate crowd and queue management to be ensured to ensure social\n" +
                    "distancing norms.\n" +
                    "b. In food courts and restaurants, not more than 50% of seating capacity to be\n" +
                    "permitted.\n" +
                    "c. Food court staff / waiters should wear mask and hand gloves and take other\n" +
                    "required precautionary measures.\n" +
                    "d. The seating arrangement should ensure adequate social distancing between\n" +
                    "patrons as far as feasible.\n" +
                    "e. Contactless mode of ordering and digital mode of payment (using e-wallets)\n" +
                    "to be encouraged.\n" +
                    "f. Tables to be sanitized each time customer leaves.\n" +
                    "g. In the kitchen, the staff should follow social distancing norms at work place.\n" +
                    "xxvii. Gaming Arcades shall remain closed.\n" +
                    "xxviii. Children Play Areas shall remain closed.\n" +
                    "xxix. Cinema halls inside shopping malls shall remain closed.\n" +
                    "xxx. In case of a suspect or confirmed case in the premises:\n" +
                    "a. Place the ill person in a room or area where they are isolated from others.\n" +
                    "b. Provide a mask/face cover till such time he/she is examined by a doctor.\n" +
                    "c. Immediately inform the nearest medical facility (hospital/clinic) or call the\n" +
                    "state or district helpline.\n" +
                    "d. A risk assessment will be undertaken by the designated public health\n" +
                    "authority (district RRT/treating physician) and accordingly further action be\n" +
                    "initiated regarding management of case, his/her contacts and need for\n" +
                    "disinfection.\n" +
                    "e. Disinfection of the premises to be taken up if the person is found positive. ");
        }

        else if(title.equals("Sending Kids to school, camp or day care")){
            txtView.setText("1. Physical distancing. The goal should be to stay at least 6 feet apart to help prevent the spread of the virus that causes COVID-19. However, spacing desks at least 3 feet apart and avoiding close contact may have similar benefits for students--especially if students wear cloth face coverings and do not have symptoms of illness.\n" +
                    "\n" +
                    "2. Teachers and staff, who are likely more at risk of getting COVID-19 from other adults than from children at school, should stay the full 6 feet apart from each other and students when possible. Teachers and staff should also wear cloth face coverings and limit in-person meetings with other adults.\n" +
                    "\n" +
                    "3. When possible, outdoor spaces can be used for instruction and meals. Students should also have extra space to spread out during activities like singing and exercising.\n" +
                    "\n" +
                    "4. Cloth face coverings & hand hygiene. Frequent hand washing with soap and water is important for everyone. In addition, all adults should wear cloth face coverings. Preschool and elementary students can benefit from wearing masks if they do not touch their mouths or noses a lot. Secondary school students should wear cloth face masks, especially when they can't stay a safe distance apart.\n" +
                    "\n" +
                    "5. Classroom changes. To help limit student interaction outside the classroom, schools can:\n" +
                    "\n" +
                    "6. Have teachers move between classrooms, rather than having students fill the hallways during passing periods.\n" +
                    "\n" +
                    "7. Allow students to eat lunches at their desks or in small groups outdoors instead of in crowded lunchrooms.\n" +
                    "\n" +
                    "8. Leave classroom doors open to help reduce high touch surfaces such as doorknobs.\n" +
                    "\n" +
                    "9. Temperature checks and testing. COVID testing \u200Bof all students is not possible for most schools. Taking students' temperature at school also may not always be feasible. Schools should establish ways to identify students with fever or other symptoms of illness. \u200BThey can also frequently remind students, teachers, and staff to stay home if they have a fever of 100.4 degrees or higher or have any signs of illness.\n" +
                    "\n" +
                    "10. Cleaning and disinfecting. Schools should follow CDC guidelines on proper disinfecting and sanitizing classrooms and common areas.\n" +
                    "\n" +
                    "11. Buses, hallways and playgrounds\n" +
                    "Since these are often crowded spaces, schools can:\n" +
                    "Give bus riders assigned seats and require them to wear a cloth face coverings while on the bus. Encourage students who have other ways to get to school to use those options.\n" +
                    "At school, mark hallways and stairs with one-way arrows on the floor to cut down on crowding in the halls.\n" +
                    "Outdoor activities are encouraged, so students should be allowed to use the playground in small groups.\n" +
                    "\n" +
                    "12. Other considerations\n" +
                    "a)In addition to having plans in place to keep students safe, there are other factors that school communities need to address:\n" +
                    "b)Pressure to catch up. Students may not have gained as much from distance learning. Some students may not have had access to computers and internet. Schools should be prepared to adjust curricula and not expect to make up all lost progress. It is important to balance core subjects with physical education and other learning experiences.\n" +
                    "c)Students with disabilities. The impact of schools being closed may have been greater for students with disabilities. They may have a difficult time transitioning back to school after missing out on instruction time as well as school-based services such as occupational, physical and speech-language therapy and mental health support counseling. School should review the needs of each child with an Individual Education Program before they return to school, and providing services even if they are done virtually.\n" +
                    "d)\u200BImmunizations. It is important as students return to school that they are up to date on their immunizations. It will be critical that stud\u200Bents and staff get their flu shot this year to reduce the spread of influenza this fall and winter. Your pediatrician is available now to make sure you child is ready for school.\n" +
                    "e)Exams. \u200B If your child participates in extracurricular activities like sports or band, talk with your pediatrician to see if they need a preparticipation physical exam.  Key well-child visits\u200B are also important.  \n" +
                    "f)Behavioral health/emotional support. Your child's school should anticipate and be prepared to address a wide range of mental health needs of students and staff. Schools should provide mental health support to any student struggling with stress from the pandemic and recognize students who show signs of anxiety or distress. Schools also can help students with suicidal thoughts or behavior get needed support.\n" +
                    "g)Nutrition. Many students receive healthy meals through school meal programs More students might be eligible for free or reduced meals than before the pandemic. Schools should provide meal programs even if the school closes or the student is sick and stays home from school.\n" +
                    "h)Students at higher risk. While COVID-19 school policies can reduce risk, they will not prevent it entirely. Even with safety steps in place, some students with high-risk medical conditions may need to continue distance learning or other accommodations. Talk with your pediatrician and school staff (including school nurses) to determine if your child can safely return to school.\n" +
                    "i)Remember\n" +
                    "Returning to school during the COVID-19 pandemic may not feel like normal – at least for a while. But having school plans in place can help keep students, staff, and families safe.\n" +
                    "j)Schools should also prepare to close again and temporarily switch to distance");
        }
        else if(title.equals("Working a week in a office building")){
            txtView.setText("The low-cost measures below will help prevent the spread of infections in your workplace, such as colds,flu and stomach bugs, and protect your customers, contractors and employees. Employers should start doing these things now, even if COVID-19 has not arrived in the communities where they operate. They can already reduce working days lost due to illness and stop or slow the spread of COVID-19 if it arrives at one of your workplaces.\n" +
                    "• Make sure your workplaces are clean and hygienic\n" +
                    "  \to Surfaces (e.g. desks and tables) and objects (e.g. telephones, keyboards) need to be wiped with disinfectant regularly\n" +
                    "\to Why? Because contamination on surfaces touched by employees and customers is one of the main ways that COVID-19 spreads\n" +
                    "• Promote regular and thorough hand-washing by employees, contractors and customers\n" +
                    "\to Put sanitizing hand rub dispensers in prominent places around the workplace. Make sure these dispensers are regularly refilled\n" +
                    "\to Display posters promoting hand-washing – ask your local public health authority for thes or look on www.WHO.int.\n" +
                    "\to Combine this with other communication measures such as offering guidance from occupational health and safety officers, briefings at meetings and information on the intranet to promote hand-washing\n" +
                    "\to Make sure that staff, contractors and customers have access to places where they can wash their hands with soap and water\n" +
                    "\to Why? Because washing kills the virus on your hands and prevents the spread of COVID19\n" +
                    "• Promote good respiratory hygiene in the workplace\n" +
                    "\to Display posters promoting respiratory hygiene. Combine this with other communication measures such as offering guidance from occupational health and safety officers, briefing at meetings and information on the intranet etc.\n" +
                    "\to Ensure that face masks1 and / or paper tissues are available at your workplaces, for those who develop a runny nose or cough at work, along with closed bins for hygienically disposing of them\n" +
                    "\to Why? Because good respiratory hygiene prevents the spread of COVID-19\n" +
                    "\t\t• Advise employees and contractors to consult national travel advice before going on business trips.\n" +
                    "\t\t• Brief your employees, contractors and customers that if COVID-19 starts spreading in your community anyone with even a mild cough or low-grade fever (37.3 C or more) needs to stay at home. They should also stay home (or work from home) if they have had to take simple medications, such as paracetamol/acetaminophen, ibuprofen or aspirin, which may mask symptoms of infection.\n" +
                    "\to Keep communicating and promoting the message that people need to stay at home even if they have just mild symptoms of COVID-19.\n" +
                    "\to Display posters with this message in your workplaces. Combine this with other communication channels commonly used in your organization or business.\n" +
                    "\to Your occupational health services, local public health authority or other partners may have developed campaign materials to promote this message\n" +
                    "\to Make clear to employees that they will be able to count this time off as sick leave. ");
        }
        else if(title.equals("Visiting an elderly relative or friend in there home")){
            txtView.setText("1. As much as possible, keep away from other people and pets in your home.\n" +
                    "2. Wear a cloth face covering (or face mask, if you have one) if they must be around other people. Cloth face coverings are for use only by people older than 2 years old who are not having trouble breathing. Do not leave a child alone while they're wearing a cloth face covering. To see how to put on and remove cloth face coverings and face masks, clean them, or make your own cloth face covering, check the CDC's guide.\n" +
                    "3. Cover coughs and sneezes with a tissue, throw the tissue away, and then wash their hands right away. Wash with soap and water for at least 20 seconds, or use alcohol-based hand sanitizer.\n" +
                    "4. If possible, stay in a bedroom and use a bathroom separate from other people in the home.\n" +
                    "5. Use separate dishes, glasses, cups, and eating utensils and not share these with other household members. After use, run them through the dishwasher or wash with very hot soapy water.\n" +
                    "6. Use separate bedding and towels and not share these with other household members. ");
        }
        else if(title.equals("Going to a salon or barbershop")){
            txtView.setText("When making a hair or nail appointment, ask about safety measures. You might be required to attend your appointment alone, wash your hair at home to reduce traffic near the shampoo area, and wait in your car or outside until your appointment begins. In addition, you might ask whether the salon is offering blow drying. Eliminating blow drying could reduce the spread of germs.\n" +
                    "\n" +
                    "Ideally, the salon will stagger appointments to limit how many people are in the facility at the same time. You might ask about the salon's disinfecting practices. Is the staff regularly wiping down high-touch surfaces? Are chairs and headrests disinfected after they are used? Is the staff wearing cloth face coverings and regularly washing their hands? Are they wearing single-use gloves for nail and facial work? Also, look for touchless payment options.");
        }
        else if(title.equals("Attending a funeral")){
            txtView.setText("Practice social distancing while making funeral arrangements\n" +
                    "1. Consider having virtual or phone meetings instead of in-person meetings with funeral home staff, cemetery staff, clergy or officiants, and others to plan funeral arrangements.\n" +
                    "2. If you need to meet in person, follow everyday preventive actions to protect yourself and others from COVID-19, such as wearing a cloth face covering, social distancing, washing your hands often, and covering coughs and sneezes.\n" +
                    "3. Do not attend in-person meetings if you are sick, might have been exposed to COVID-19, or have higher risk of severe illness from COVID-19.\n" +
                    "\n" +
                    "Discuss options for making changes to traditional funeral plans\n" +
                    "1. Discuss your cultural or religious traditions and the funeral wishes of the deceased, if applicable, with family members and the people you are working with (funeral home staff, clergy, or officiants).\n" +
                    "2. Identify any potential concerns and determine options to make changes to prevent the spread of COVID-19. Preserve traditional practices when it is possible to safely do so, and identify whether modified or new practices could satisfy the needs and values of you and your loved one.\n" +
                    "3. Consider whether it would be acceptable to hold modified funeral arrangements by limiting attendance to a small number of immediate family members and friends shortly after the time of death. Consider holding additional memorial services in the future when social distancing guidelines are less restrictive.\n" +
                    "4. When you are making decisions about who should attend, consider how emotionally difficult social distancing practices might be for attendees (such as keeping at least 6 feet apart and not hugging other attendees who do not live in their household).\n" +
                    "5. Ask the people you are working with (funeral home staff, clergy, or officiant) about resources they may be able to provide, such as:\n" +
                    "\ta) Virtual funeral services, visitations, and memorial tributes by online video streaming or recorded video. Consider potential issues with virtual attendees’ access to technology and high-speed internet, as well as how any technological difficulties during the service could impact the event.\n" +
                    "\tb) Online guestbooks or memory books that invite people to share stories, notes of condolence, or photos.\n" +
                    "\tc) Assistance with sharing details about the plan for funeral services and visitations with extended family and friends, including how to compassionately communicate any changes to traditional practices and the reasons they are necessary.");
        }
        else if(title.equals("Attending a wedding")){
            txtView.setText("The advisory for events like marriages mentions the following guidelines.\n" +
                    "1. Marriages can be held with no more than 50 guests.\n" +
                    "2. The event must be conducted in a public place with good natural ventilation. Weddings should not be conducted in air-conditioned halls.\n" +
                    "3. Sanitizers must be provided at the entrance and at other appropriate places\n" +
                    "4. Washrooms to have soap and water for all guests to wash their hands\n" +
                    "5. The venue must be clean and hygienic\n" +
                    "6. An individual must be nominated at the nodal person to oversee all arrangements and co-ordination at the venue.\n" +
                    "7. A list of all attendees must be maintained with their contact details\n" +
                    "8. Spitting is prohibited in all public places\n" +
                    "9. All guests must have their temperature taken with a thermal scanner before entering the venue.\n" +
                    "10. Consumption of liquor, tobacco, gutka and paan is not allowed.\n" +
                    "\n" +
                    "Conducting Wedding During COVID-19 – Guidelines For Guests\n" +
                    "1. All guests must install the Aarogya Setu app and have their Bluetooth on\n" +
                    "2. People from containment areas cannot attend the event\n" +
                    "3. Guests may get travel passes to attend the wedding from local authorities\n" +
                    "4. People above the age of 65 years, children below the age of 10 years and pregnant women will not be allowed to attend the event.\n" +
                    "5. Any guest with a fever above 99.5˚F or 37.5˚C, cough, cold or difficulty breathing will not be permitted to attend the wedding.\n" +
                    "6. Everyone involved in the wedding must wear a face mask\n" +
                    "7. Physical distance of at least 1 m should be maintained between 2 individuals");
        }
        else if(title.equals("Travelling by plane")){
            txtView.setText("1. Make An Inventory List: As a general rule, there are a few items that you should carry with you while travelling. Your list should include a hand sanitiser (with more than 60% alcohol content), disinfectant wipes, tissues, and a face mask. These items can help you maintain a certain level of hygiene and prevent contact with disease-causing respiratory droplet.\n" +
                    "\n" +
                    "2. Be Mindful Of What You Touch: You would have read that the novel coronavirus has been spreading at an accelerated rate. This merits a heightened sense of caution. It’s important to be mindful when using devices or touching surfaces that others have used too, such as ATMs, check-in machines, escalators and the like. Use a generous amount of sanitiser whenever you touch any of these surfaces and be careful not to touch your face. Similarly, be mindful of your own high-touch items, such as phones and wallets. Keep them in a bag rather than exposed in bins during security checks. Your phone is constantly being handled (without you paying much attention to what you touched before it). So wiping it down with disinfectant a couple of times a day is advisable.\n" +
                    "\n" +
                    "3. Minimise Human Contact : Wherever possible, try to rely on technology and automation. Get your boarding pass from the machine and sanitise your hands afterwards. In terms of food and retail outlets within the airport, try not to touch common surfaces, maintain the recommended six-foot distance from the staff, and try to pay using contactless options.\n" +
                    "\n" +
                    "4. Get A Window: While choosing your seat on a plane may not be in your hands immediately after travel is resumed, when you can, always opt for the window. A study by researchers at Emory University and Georgia Tech found that the best way to avoid germs on a plane is to sit at a window seat and remain seated for the course of the flight. Infected passengers will most likely not infect people sitting farther than two seats beside them or one or two rows in front or behind. Risk of indirect transmission can be eliminated by keeping hands clean and avoiding contact with eyes, nose and mouth.\n" +
                    "\n" +
                    "5. Wipe Down Your Surroundings: While taking your seat, take a page out of Naomi Campbell’s book and do a quick scrub down of the hard surfaces around you with disinfectant wipes. The back of the seat in front of you, the seat flap, the tray table, the arm rests, are all surfaces where infectious respiratory droplets can remain alive. Be sure to allow the surfaces to remain wet for the time it takes for the disinfectant to work (which is usually mentioned on the box) and to not use wipes on soft surfaces, such as upholstery which would leave an uncomfortable wet seat and spread the germs out further. Also, remember that the coronavirus will not directly infect you from such surfaces, only when you touch an infected surface and then touch your face (the entry points so far are via your nose, mouth and eyes). As such, whenever you touch surfaces that many others may have as well (touchscreens or the handle to the bathroom), try to use tissues to avoid direct contact with surfaces and dispose of the tissues safely when you’re done.\n" +
                    "\n" +
                    "6. Don’t Drink Water: According to the US Environmental Protection Agency, the water from airplane water tanks is not always clean, so drinking tea or coffee, which is usually made from this water and not bottled water, might not be a good idea. \n" +
                    "\n" +
                    "7. Stay Home If You’re Sick: This is the most important point. More often than not, we focus on how to protect ourselves from the disease, but don’t think about preventing ourselves from spreading it. The CDC recommends waiting a minimum of 24 hours after a fever has completely abated before stepping out. It’s important to think about everyone if this virus is ever to be contained.");
        }
        else if(title.equals("Minimal Contact Sports")){
            txtView.setText("Training activities may be performed in small groups (maximum 8-10) maintaining distancing norms of 1.5 to 2 metres between athletes and staff and ensuring aspects of training which require physical contact are avoided like tacking, body blocking etc.; the pitch should be divided into three/four areas, with maximum of three players in each space who will train and stick to their partnerships should a player test positive for coronavirus; chief coach and the assistant coach shall oversee proceedings from the safe distance/ video tower, with the payer of only staff allowed to pick up balls and cones which would then be disinfected; training shall be in a small groups, players staying 10 metres from each other during exercises and sessions not exeeding one hour per day. However, \"drastic measures\" shall be taken to avoid with no competitive games being played; Personal equipment such as hockey stick, gloves, face masks, rackets, mouth guard, helmet, shin guards, wrist band, head band, shoes etc. shall be used with out sharing. Athletes shall exit facility as soon as training is concluded.");
        }
        else if(title.equals("Working out at a gym")){
            txtView.setText("Before going to the gym, call to see if it's limiting how many members are allowed in at the same time. You might have to reserve a block of time in advance, with staff cleaning the facility between blocks. Ask about the facility's cleaning and disinfecting policies and whether you'll be able to use the locker room or bathroom. If you are interested in group exercise classes, ask if they are being offered.\n" +
                    "\n" +
                    "Your gym will likely enforce social distancing by blocking access to every other cardio machine or by putting up barriers around equipment. Follow the gym's guidelines and stay at least 6 feet (2 meters) away from other members. Clean equipment before and after using it. Some equipment that's difficult to clean, such as foam rollers and yoga blocks, might not be available.\n" +
                    "\n" +
                    "If you're at higher risk of serious illness, you might consider waiting to return to the gym. Ask if your gym offers virtual classes or training.");
        }
        else if(title.equals("Going to a amusement park")){
            txtView.setText("Before heading out, check with state and local authorities to see if parks, recreational facilities, natural bodies of water, beaches and swim areas are open. The National Park Service will decide on a park-by-park basis if a national park will open. If an area is going to be open, check if bathrooms and food concession stands also are open.\n" +
                    "\n" +
                    "Choose a park that is close to home. Travel often involves stops, which can expose you to the COVID-19 virus. Keep space between yourself and others when using swimming pools.\n" +
                    "\n" +
                    "While at the park, look for open areas, trails and paths that allow you to keep a distance of 6 feet (2 meters) from others. Avoid crowded areas.");
        }
        else if(title.equals("Attending a religious service with 500+ worshipers")){
            txtView.setText("Before going to a place of worship, check to see if the size of gatherings is being limited and how that might affect your visit. Seek out services held in large, well-ventilated areas. Continue social distancing during services.\n" +
                    "\n" +
                    "Also, avoid contact with frequently touched items, such as books. Place any donations in a stationary collection box. If food is offered at an event, look for pre-packaged options.");
        }
        else if(title.equals("Going to a Massage Therapy")){
            txtView.setText("Before having a massage, ask about what precautions your massage therapist is taking to prevent the spread of the COVID-19 virus. Ideally, the number of people in the space will be limited to allow for social distancing and you'll be able to check in and out using virtual tools.\n" +
                    "\n" +
                    "Massage rooms, communal areas and any objects you might touch should be thoroughly cleaned, disinfected and sanitized. Ask about the laundry policy for linens, towels and other washable items. Massage therapists should follow hand-washing and hygiene protocols and use equipment to protect themselves, such as gloves and masks.\n");
        }

    }

    @Override
    public void onBackPressed() {
        if (backPressedTime + 2000 > System.currentTimeMillis()) {
            finishQuiz();
        } else {
            Toast.makeText(this, "Press back again to finish", Toast.LENGTH_SHORT).show();
        }

        backPressedTime = System.currentTimeMillis();
    }

    private void finishQuiz() {
        Intent intentresult = new Intent();
        setResult(RESULT_OK, intentresult);
        finish();
    }

}
