package com.thecodinghound.preventionandcontainment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentVolunteer extends Fragment {

    private WebView myWebView;


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragmentvolunteer, container, false);

        myWebView = (WebView) v.findViewById(R.id.webviewVolunteer);
        myWebView.setWebViewClient(new WebViewClient());
        myWebView.loadUrl("https://preventionandcontainmentfromcorona.000webhostapp.com/voulnteer.html");
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        return v;
    }
}
