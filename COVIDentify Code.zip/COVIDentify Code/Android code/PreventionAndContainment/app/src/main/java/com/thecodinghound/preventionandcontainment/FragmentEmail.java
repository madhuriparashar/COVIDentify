package com.thecodinghound.preventionandcontainment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentEmail extends Fragment {

    TextView edittextsubject;
    TextView edittextmessage;
    Button buttonsend;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v= inflater.inflate(R.layout.fragment_email, container, false);

        edittextsubject = v.findViewById(R.id.edit_text_Subject);
        edittextmessage = v.findViewById(R.id.edit_text_Message);

        buttonsend = v.findViewById(R.id.button_send);

        buttonsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendemail();
            }
        });
        return v;
    }
    private void sendemail(){
        String recipientList = "viveksharmavicky928@gmail.com";
        String[] recipients = recipientList.split(",");

        String subject = edittextmessage.getText().toString();
        String message = edittextmessage.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL,recipients);
        intent.putExtra(Intent.EXTRA_SUBJECT,subject);
        intent.putExtra(Intent.EXTRA_TEXT,message);

        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent,"Choose an email client"));
    }

}
