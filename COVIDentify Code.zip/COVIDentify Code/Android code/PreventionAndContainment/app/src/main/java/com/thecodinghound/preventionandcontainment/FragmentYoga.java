package com.thecodinghound.preventionandcontainment;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentYoga extends Fragment {

    private WebView myWebView;


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_yoga, container, false);

        myWebView = (WebView) v.findViewById(R.id.webview);
        myWebView.setWebViewClient(new WebViewClient());
        myWebView.loadUrl("https://preventionandcontainmentfromcorona.000webhostapp.com/YogaDiet.html");
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        return v;
    }
//
//    public class myWebClient extends WebViewClient {
//
//        public void onPageStarted(WebView view, String url, Bitmap favicon){
//            super.onPageStarted(view,url,favicon);
//        }
//
//        public boolean shouldOverrideUrlLoading(WebView view, String url){
//            view.loadUrl(url);
//            return true;
//        }
//    }

}
