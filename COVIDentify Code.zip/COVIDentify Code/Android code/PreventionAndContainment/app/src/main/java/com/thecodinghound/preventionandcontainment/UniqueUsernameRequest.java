package com.thecodinghound.preventionandcontainment;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class UniqueUsernameRequest extends StringRequest
{
    private static final String Unique_Request_URL= "https://preventionandcontainmentfromcorona.000webhostapp.com/UniqueUsername.php";
    private Map<String, String> params;

    public UniqueUsernameRequest( String phone, Response.Listener<String> listener)
    {
        super(Request.Method.POST, Unique_Request_URL,listener,null);
        params = new HashMap<>();
        params.put("phone",phone);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
