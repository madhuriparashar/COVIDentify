package com.thecodinghound.preventionandcontainment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {


    public static final String SHARED_PREFS = "sharedPrefs";
    public static final String KEY_LOGIN = "keylogin";
    public static final String KEY_Phone = "keyphone";
    public static final String KEY_RiskFactor = "keyriskfactor";

    private int login;
    private String phone;
    private String riskfactor;
    private String phoneLogin;
    private String riskfactorLogin;

    private long backPressedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText etphone = (EditText) findViewById(R.id.etPhoneNumber);
        final EditText etpassword = (EditText) findViewById(R.id.etPassword);
        final Button blogin = (Button) findViewById(R.id.bLogin);
        final TextView etregister = (TextView) findViewById(R.id.etRegister);

        logoutstatus();
        loadlogin();
        if (login == 1) {
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.putExtra("phone", phoneLogin);
            intent.putExtra("riskfactor", riskfactorLogin);
            startActivity(intent);
        } else {
            etregister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent registerintent = new Intent(LoginActivity.this, RegisterActivity.class);
                    LoginActivity.this.startActivity(registerintent);

                }
            });

            blogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    final String phone = etphone.getText().toString();
                    final String password = etpassword.getText().toString();

                    Response.Listener<String> responseListener = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("response is", response);

                            try {
                                JSONObject jsonResponse = new JSONObject(response);
                                boolean success = jsonResponse.getBoolean("success");

                                Log.d("success", String.valueOf(success));
                                if (success) {
                                    String phone = jsonResponse.getString("phone");
                                    String riskfactor = jsonResponse.getString("riskfactor");

                                    updateLogin(1,phone,riskfactor);

                                    Log.d("entered", "if loop");
                                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                    intent.putExtra("phone", phone);
                                    intent.putExtra("riskfactor", riskfactor);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                                    builder.setMessage("Login Failed").setNegativeButton("Retry", null)
                                            .create().show();
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    };
                    LoginRequest loginRequest = new LoginRequest(phone, password, responseListener);
                    RequestQueue queue = Volley.newRequestQueue(LoginActivity.this);
                    queue.add(loginRequest);
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if(backPressedTime + 2000 >  System.currentTimeMillis())
        {
            finish();
        }
        else{
            Toast.makeText(LoginActivity.this,"Press back again to finish" , Toast.LENGTH_SHORT);
        }
        backPressedTime = System.currentTimeMillis();
    }

    private void loadlogin() {
        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        login = prefs.getInt(KEY_LOGIN, 0);
        phone = prefs.getString(KEY_Phone, " ");
        riskfactor = prefs.getString(KEY_RiskFactor, " ");
    }

    private void updateLogin(int status, String phone, String riskfactor) {
        login = status;
        phoneLogin = phone;
        riskfactorLogin = riskfactor;


        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_LOGIN, login);
        editor.putString(KEY_Phone, phoneLogin);
        editor.putString(KEY_RiskFactor, riskfactorLogin);
        editor.apply();
    }

    public  void logoutstatus() {
        Log.d("Called",""+login);
        Intent intent = getIntent();
        int logout = intent.getIntExtra("logout", 0);
        if (logout == 1) {
            updateLogin(0, null, null);
        }
    }

}

