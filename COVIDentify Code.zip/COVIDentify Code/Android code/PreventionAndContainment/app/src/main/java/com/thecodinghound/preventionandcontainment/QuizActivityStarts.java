package com.thecodinghound.preventionandcontainment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.Random;

public class QuizActivityStarts extends AppCompatActivity {

    public static final String EXTRA_SCORE = "extraScore";
    public static final String EXTRA_ID = "extracategoryid";
//    private static final long COUNTDOWN_IN_MILLIS = 120000;

    private static final String KEY_SCORE = "keyScore";
    private static final String KEY_Question_Count = "keyQuestionCount";
    private static final String KEY_MILLIS_LEFT = "keyMillisLeft";
    private static final String KEY_Answered = "keyAnswered";
    private static final String KEY_Question_List = "keyQuestionList";

    private TextView textViewQuestion;
    private TextView textViewQuestionCount;

    private RadioGroup rbGroup;
    private RadioButton rb1;
    private RadioButton rb2;
    private RadioButton rb3;
    private RadioButton rb4;
    private Button buttonConfirmNext;

    private ColorStateList textColorDefaultRb;
    private ColorStateList textColorDefaultCd;

//    private CountDownTimer countDownTimer;
//    private long timeLeftInMillis;

    private ArrayList<Question> questionList;
    private int questionCounter;
    private int questionCountTotal;
    private Question currentQuestion;

    private int score;
    private boolean answered;


    private long backPressedTime;

    String[] quotesRandom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_starts);

        textViewQuestion = findViewById(R.id.text_view_question);

        textViewQuestionCount = findViewById(R.id.text_view_question_count);


        rbGroup = findViewById(R.id.radio_group);
        rb1 = findViewById(R.id.radio_button1);
        rb2 = findViewById(R.id.radio_button2);
        rb3 = findViewById(R.id.radio_button3);
        rb4 = findViewById(R.id.radio_button4);
        buttonConfirmNext = findViewById(R.id.button_confirm_next);

        textColorDefaultRb = rb1.getTextColors();


        Intent intent = getIntent();

        quotesRandom = new String[4];
        quotesRandom[0] = "Nothing lasts forever. Not even the coronavirus. So stay home, stay safe and fight hard.";
        quotesRandom[1] = "Stay home, stay safe – the only medicine found till now for coronavirus.";
        quotesRandom[2] = "Positive anything is better than negative nothing - except the coronavirus. So stay home and help flatten the curve.";
        quotesRandom[3] = "A powerful attitude awakens inner strength, energy, motivation, and initiative. Keep your attitude positive and fight the coronavirus by staying home, staying safe.";


        QuizDbHelper dbHelper = QuizDbHelper.getInstance(this);
        questionList = dbHelper.getAllQuestions();
        questionCountTotal = questionList.size();
        Collections.shuffle(questionList);

        showNextQuestion();

        buttonConfirmNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!answered) {
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked() || rb4.isChecked()) {
                        checkAnswer();
                    } else {
                        Toast.makeText(QuizActivityStarts.this, "Please select an answer", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    showNextQuestion();
                }
            }
        });
    }




    private void showNextQuestion() {
        rb1.setTextColor(textColorDefaultRb);
        rb2.setTextColor(textColorDefaultRb);
        rb3.setTextColor(textColorDefaultRb);
        rb4.setTextColor(textColorDefaultRb);
        rbGroup.clearCheck();

        if (questionCounter < questionCountTotal) {
            currentQuestion = questionList.get(questionCounter);

            textViewQuestion.setText(currentQuestion.getQuestion());
            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());
            rb4.setText(currentQuestion.getOption4());

            questionCounter++;
            textViewQuestionCount.setText("Question: " + questionCounter + "/" + questionCountTotal);
            answered = false;
            buttonConfirmNext.setText("Confirm");
        } else {
            finishQuiz();
        }
    }

    private void checkAnswer() {
        answered = true;

        RadioButton rbSelected = findViewById(rbGroup.getCheckedRadioButtonId());
        int answerNr = rbGroup.indexOfChild(rbSelected) + 1;

        if (answerNr == currentQuestion.getAnswerNr()) {
            score++;
        }

        showSolution(answerNr);
    }


    public static String getRandom(String[] array) {
        int rnd = new Random().nextInt(array.length);
        return array[rnd];
    }

    private void showSolution(int answerNr) {
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);
        rb4.setTextColor(Color.RED);




        switch (currentQuestion.getAnswerNr()) {
            case 1:
                rb1.setTextColor(Color.GREEN);
                if(answerNr == 1){
                    textViewQuestion.setText("You simply have to put one foot in front of the other and keep going. Put blinders on and plow right ahead.");
                }
                else{
                    textViewQuestion.setText(getRandom(quotesRandom));
                }
                break;
            case 2:
                rb2.setTextColor(Color.GREEN);
                if(answerNr == 2){
                    textViewQuestion.setText("You simply have to put one foot in front of the other and keep going. Put blinders on and plow right ahead.");
                }
                else{
                    textViewQuestion.setText(getRandom(quotesRandom));
                }
                break;
            case 3:
                rb3.setTextColor(Color.GREEN);
                if(answerNr == 3){
                    textViewQuestion.setText("You simply have to put one foot in front of the other and keep going. Put blinders on and plow right ahead.");
                }
                else{
                    textViewQuestion.setText(getRandom(quotesRandom));
                }
                break;
            case 4:
                rb4.setTextColor(Color.GREEN);
                if(answerNr == 4){
                    textViewQuestion.setText("You simply have to put one foot in front of the other and keep going. Put blinders on and plow right ahead.");
                }
                else{
                    textViewQuestion.setText(getRandom(quotesRandom));
                }
        }

        if (questionCounter < questionCountTotal) {
            buttonConfirmNext.setText("Next");
        } else {
            buttonConfirmNext.setText("Finish");
        }
    }


    private void finishQuiz() {
        Intent resultIntent = new Intent();
        resultIntent.putExtra(EXTRA_SCORE, score);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    @Override
    public void onBackPressed() {
        if(backPressedTime + 2000 >  System.currentTimeMillis())
        {
            finishQuiz();
        }
        else{
            Toast.makeText(QuizActivityStarts.this,"Press back again to finish" , Toast.LENGTH_SHORT);
        }
        backPressedTime = System.currentTimeMillis();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_SCORE,score);
        outState.putInt(KEY_Question_Count, questionCounter);
        outState.putBoolean(KEY_Answered, answered);
        outState.putParcelableArrayList(KEY_Question_List,questionList);
    }



}
