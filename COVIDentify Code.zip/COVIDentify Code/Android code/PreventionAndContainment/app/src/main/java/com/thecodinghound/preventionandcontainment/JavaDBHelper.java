package com.thecodinghound.preventionandcontainment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import com.thecodinghound.preventionandcontainment.JavaContract.*;

public class JavaDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MyJava.db";
    private static final int DATABASE_VERSION = 1;

    private static JavaDBHelper instance;

    private SQLiteDatabase db;

    public JavaDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    public static synchronized JavaDBHelper getInstance(Context context) {
        if (instance == null) {
            instance = new JavaDBHelper(context.getApplicationContext());
        }
        return instance;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        db = sqLiteDatabase;

        final String SQL_CREATE_TOPICS_TABLE = "CREATE TABLE " +
                JavaTopics.TABLE_NAME + " ( " +
                JavaTopics._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                JavaTopics.COLUMN_TITLE + " TEXT, " +
                JavaTopics.COLUMN_CONTENT + " TEXT, " +
                JavaTopics.COLUMN_DATE + " TEXT, " +
                JavaTopics.COLUMN_USERPHOTO + " INTEGER " +
                ")";


        db.execSQL(SQL_CREATE_TOPICS_TABLE);
        fillTopicsTable();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + JavaTopics.TABLE_NAME);
        onCreate(db);
    }

    private void fillTopicsTable() {
        MainTopicName J9 = new MainTopicName("Minimal Common Measures","-Mandatory common precautions you should take no matter where you are heading.","",R.drawable.washyourhands);
        addTopic(J9);
        MainTopicName J1 = new MainTopicName("Getting restaurant takeout","- Low Risk \n- Risk Factor = 2","",R.drawable.arrow);
        addTopic(J1);
        MainTopicName J2 = new MainTopicName("Pumping Gasoline","- Low Risk \n- Risk Factor = 2","",R.drawable.arrow);
        addTopic(J2);
        MainTopicName J3 = new MainTopicName("Non Contact Sports","- Such as Archery, Shooting, Fencing, Athletics, Weightlifting, Lawn Tennis, Badminton, Table Tenis\n- Low Risk \n- Risk Factor = 2","",R.drawable.arrow);
        addTopic(J3);
        MainTopicName J5 = new MainTopicName("Grocery Shopping","- Moderate Low Risk\n- Risk Factor = 3","",R.drawable.arrow);
        addTopic(J5);
        MainTopicName J6 = new MainTopicName("Going for a walk, run or bike ride with others","- Moderate Low Risk\n- Risk Factor = 3","",R.drawable.arrow);
        addTopic(J6);
        MainTopicName J7 = new MainTopicName("Staying at a hotel for 2 nights","- Moderate Low Risk\n- Risk Factor = 4","",R.drawable.arrow);
        addTopic(J7);
        MainTopicName J8 = new MainTopicName("Visiting Doctor","- Moderate Low Risk\n- Risk Factor = 4","",R.drawable.arrow);
        addTopic(J8);
        MainTopicName J10 = new MainTopicName("Going to Banks","- Moderate Low Risk\n- Risk Factor = 4","",R.drawable.arrow);
        addTopic(J10);
        MainTopicName J11 = new MainTopicName("Eating in a restaurant(outside)","- Moderate Low Risk\n- Risk Factor = 4","",R.drawable.arrow);
        addTopic(J11);
        MainTopicName J14 = new MainTopicName("Having dinner at someone else's house","- Moderate Risk\n- Risk Factor = 5","",R.drawable.arrow);
        addTopic(J14);
        MainTopicName J16 = new MainTopicName("Going to a beach","- Moderate Risk\n- Risk Factor = 5","",R.drawable.arrow);
        addTopic(J16);
        MainTopicName J17 = new MainTopicName("Shopping at a mall","- Moderate Risk\n- Risk Factor = 6","",R.drawable.arrow);
        addTopic(J17);
        MainTopicName J18 = new MainTopicName("Sending Kids to school, camp or day care","- Moderate Risk\n- Risk Factor = 6","",R.drawable.arrow);
        addTopic(J18);
        MainTopicName J19 = new MainTopicName("Working a week in a office building","- Moderate Risk\n- Risk Factor = 6","",R.drawable.arrow);
        addTopic(J19);
        MainTopicName J21 = new MainTopicName("Visiting an elderly relative or friend in there home","- Moderate Risk\n- Risk Factor = 6","",R.drawable.arrow);
        addTopic(J21);
        MainTopicName J22 = new MainTopicName("Going to a salon or barbershop","- Moderate High\n- Risk Factor = 7","",R.drawable.arrow);
        addTopic(J22);
        MainTopicName J24 = new MainTopicName("Attending a funeral","- Moderate High\n- Risk Factor = 7","",R.drawable.arrow);
        addTopic(J24);
        MainTopicName J20 = new MainTopicName("Attending a wedding","- Moderate High\n- Risk Factor = 7","",R.drawable.arrow);
        addTopic(J20);
        MainTopicName J25 = new MainTopicName("Travelling by plane","- Moderate High\n- Risk Factor = 7","",R.drawable.arrow);
        addTopic(J25);
        MainTopicName J26 = new MainTopicName("Minimal Contact Sports","- Such as football, Hockey, volleyball, baskteball, handball\n- Moderate High\n- Risk Factor = 7","",R.drawable.arrow);
        addTopic(J26);
        MainTopicName J29 = new MainTopicName("Working out at a gym","- High Risk\n- Risk Factor = 8","",R.drawable.arrow);
        addTopic(J29);
        MainTopicName J30 = new MainTopicName("Going to a amusement park","- High Risk\n- Risk Factor = 8","",R.drawable.arrow);
        addTopic(J30);
        MainTopicName J34 = new MainTopicName("Attending a religious service with 500+ worshipers","- High Risk\n- Risk Factor = 9","",R.drawable.arrow);
        addTopic(J34);
        MainTopicName J35 = new MainTopicName("Going to a Massage Therapy","- High Risk\n- Risk Factor = 9","",R.drawable.arrow);
        addTopic(J35);

    }

    private void addTopic(MainTopicName pt) {
        ContentValues cv = new ContentValues();
        cv.put(JavaTopics.COLUMN_TITLE, pt.getTitle());
        cv.put(JavaTopics.COLUMN_CONTENT, pt.getContent());
        cv.put(JavaTopics.COLUMN_DATE, pt.getDate());
        cv.put(JavaTopics.COLUMN_USERPHOTO, pt.getUserPhoto());
        db.insert(JavaTopics.TABLE_NAME,null,cv);
    }


    public ArrayList<MainTopicName> getAllTopics() {

        ArrayList<MainTopicName> topicList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + JavaContract.JavaTopics.TABLE_NAME, null);

        if (c.moveToFirst()) {
            do {
                MainTopicName pt = new MainTopicName();
                pt.setId(c.getInt(c.getColumnIndex(JavaTopics._ID)));
                pt.setTitle(c.getString(c.getColumnIndex(JavaTopics.COLUMN_TITLE)));
                pt.setContent(c.getString(c.getColumnIndex(JavaTopics.COLUMN_CONTENT)));
                pt.setDate(c.getString(c.getColumnIndex(JavaTopics.COLUMN_DATE)));
                pt.setUserPhoto(c.getInt(c.getColumnIndex(JavaTopics.COLUMN_USERPHOTO)));
                topicList.add(pt);
            } while (c.moveToNext());
        }

        c.close();
        return topicList;
    }


    public boolean updateDate(MainTopicName topic)
    {
        db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(JavaTopics._ID, topic.getId());
        cv.put(JavaTopics.COLUMN_DATE, topic.getDate());
        String[] args = {String.valueOf(topic.getId())};
        int isupdatebookmark = db.update(JavaTopics.TABLE_NAME,cv, JavaTopics._ID +" = ? ",args);
        if(isupdatebookmark > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }


}
