package com.thecodinghound.preventionandcontainment;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class FragmentTest extends Fragment {
    private static final int REQUEST_CODE_QUIZ = 1;

//    public static final String KEY_STATUS = "keyStatus";

    public static final String MyPREFERENCES = "MyPrefs";
    public static final String TEXTSTATUS = "textStatus";

    TextView textViewStatus;


    public static String TAG = "QUIZACTIVITY";

    private String RiskStatus;


    public String phone;
    private String riskfactor;
    private String duplicateRiskfactor;



    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_test, container, false);

        textViewStatus = v.findViewById(R.id.text_view_status);
        Button buttonStartQuiz = v.findViewById(R.id.button_start_quiz);
        buttonStartQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startQuiz();
            }
        });

        phone = getArguments().getString("phone1");
        riskfactor = getArguments().getString("riskfactor1");
        duplicateRiskfactor = riskfactor;
        saveData(riskfactor);
        loadData();
        return v;
    }

    private void startQuiz() {
        Intent intent = new Intent(getActivity(), QuizActivityStarts.class);
        startActivityForResult(intent, REQUEST_CODE_QUIZ);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_QUIZ) {
            if (resultCode == RESULT_OK) {
                int score = data.getIntExtra(QuizActivityStarts.EXTRA_SCORE, 0);
                if (score == 4) {
                    riskfactor = "Safe";
                } else if (score == 3) {
                    riskfactor = "Low Risk";
                } else if (score < 3) {
                    riskfactor = "High Risk";
                }

                Response.Listener<String> responseListener1 = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("response is", response);

                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            boolean success = jsonResponse.getBoolean("success");

                            Log.d("success", String.valueOf(success));
                            if (success) {
                                duplicateRiskfactor = riskfactor;
                                saveData(riskfactor);
                                loadData();

                            } else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setMessage("Error in update").setNegativeButton("Retry", null)
                                        .create().show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };

                UpdateRiskFactorRequest registerRequest = new UpdateRiskFactorRequest(phone,riskfactor, responseListener1);
                RequestQueue queue = Volley.newRequestQueue(getActivity());
                queue.add(registerRequest);


            }
        }

    }

    private void saveData(String str) {
        SharedPreferences sharedpreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpreferences.edit();
        editor.putString(TEXTSTATUS, str);

        editor.apply();
    }

    private void loadData() {
        SharedPreferences sharedpreferences = this.getActivity().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        RiskStatus = sharedpreferences.getString(TEXTSTATUS, "Please Take the Self Assessment Test to know your risk");
        textViewStatus.setText(RiskStatus);
    }


}
